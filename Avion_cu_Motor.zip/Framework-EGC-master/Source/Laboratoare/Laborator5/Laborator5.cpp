#include "Laborator5.h"

#include <vector>
#include <string>
#include <iostream>
#include <cstdlib>
#include <ctime>

#include <Core/Engine.h>
#include <Laboratoare\Laborator5\Object2DTema.h>
using namespace std;

Laborator5::Laborator5()
{
}

Laborator5::~Laborator5()
{
}

void Laborator5::Init()
{
	renderCameraTarget = false;

	camera = new Laborator::Camera();
	camera->Set(glm::vec3(0, 3, 5), glm::vec3(0, 1, 0), glm::vec3(0, 1, 0));

	//separate camera used for the UI
	camera1 = new Laborator::Camera();
	camera1->Set(glm::vec3(2, 0, 6), glm::vec3(2, 0, 0), glm::vec3(0, 1, 0));
	//plane
	{
		Mesh* mesh = new Mesh("plane");
		mesh->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "airplane6v2.obj");
		meshes[mesh->GetMeshID()] = mesh;
	}
	//propeller
	{
		Mesh* mesh1 = new Mesh("elice");
		mesh1->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "quad.obj");
		meshes[mesh1->GetMeshID()] = mesh1;
	}
	//sea
	{
		Mesh* mesh2 = new Mesh("sea");
		mesh2->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "sea.obj");
		meshes[mesh2->GetMeshID()] = mesh2;
	}
	//life
	{
		Mesh* mesh3 = new Mesh("life");
		mesh3->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "life.obj");
		meshes[mesh3->GetMeshID()] = mesh3;
	}
	//cloud cube
	{
		glm::vec3 cubeCorner = glm::vec3(0, 0, 0);
		Mesh* cube = Object2DTema::CreateCube("cube", cubeCorner, true);
		AddMeshToList(cube);
	}
	//fuel
	{
		glm::vec3 fuelCorner = glm::vec3(0, 0, 0);
		Mesh* fuel = Object2DTema::CreateFuel("fuel", fuelCorner, true);
		AddMeshToList(fuel);
	}
	//obstacle
	{
		glm::vec3 obstacleCorner = glm::vec3(0, 0, 0);
		Mesh* obst = Object2DTema::CreateObstacle("obstacle", obstacleCorner, true);
		AddMeshToList(obst);
	}
	//fuelBar - back
	{
		glm::vec3 fuelBarCorner = glm::vec3(0, 0, 0);
		Mesh* fuelBar = Object2DTema::CreateFuelBar("fuelBar1", fuelBarCorner, true, glm::vec3(0, 0, 0));
		AddMeshToList(fuelBar);
	}
	//fuelBar - front
	{
		glm::vec3 fuelBarCorner = glm::vec3(0, 0, 0);
		Mesh* fuelBar = Object2DTema::CreateFuelBar("fuelBar2", fuelBarCorner, true, glm::vec3(0.60, 0.67, 1.00));
		AddMeshToList(fuelBar);
	}
	//shaders for plane and UI
	{
		Shader* shader = new Shader("ShaderTema");
		shader->AddShader("Source/Laboratoare/Laborator5/Shaders/VertexShader.glsl", GL_VERTEX_SHADER);
		shader->AddShader("Source/Laboratoare/Laborator5/Shaders/FragmentShader.glsl", GL_FRAGMENT_SHADER);
		shader->CreateAndLink();
		shaders[shader->GetName()] = shader;
	}
	//shader for the sea
	{
		Shader* shader1 = new Shader("ShaderTemaMare");
		shader1->AddShader("Source/Laboratoare/Laborator5/Shaders/VertexShaderSea.glsl", GL_VERTEX_SHADER);
		shader1->AddShader("Source/Laboratoare/Laborator5/Shaders/FragmentShaderSea.glsl", GL_FRAGMENT_SHADER);
		shader1->CreateAndLink();
		shaders[shader1->GetName()] = shader1;
	}

	//initializations
	{
		up = 0;
		angle = 0;
		angleElice = 0.02;
		yPlane = 0.8f;
		fov = 60;
		up = 1;
		translateXElice = -1.63;
		translateYElice = yPlane + 0.16;
		cloudX = { -5.5, -5.1, -4.9, -4.5 };
		cloudX1 = { 0, 0.4, 0.6, 1 };
		cloudX2 = { 5, 5.4, 5.6, 6 };
		cloudY = { 2, 2.3, 2, 2.1 };
		angleCloud = { 0.8f, 1.0f, 2.0f, 1.0f };
		axisCloud = { glm::vec3(1, 0, 2), glm::vec3(-2, 1, 0), glm::vec3(1, 0, -1), glm::vec3(1, 0, 2) };
		scaleFactorCloud = { 0.25f, 0.15f, 0.2f, 0.25f };
		projectionMatrix = glm::perspective(RADIANS(60), window->props.aspectRatio, 0.01f, 200.0f);
		//generate random positions for fuel
		srand(time(0));
		value = rand() % 9;
		for (int i = 0; i < 4; i++) {
			fuelTranslationX[i] = value + i * 0.3f;
		}
		fuelTranslationY = { 0.3, 0.4, 0.5, 0.4 };
		translateObst1X = 4;
		translateObst1Y = 2;
		translateObst2X = 13;
		translateObst2Y = 1;
		changePerspective = 0;
		add = 0;
		colorsForTheSea = { glm::vec4(0.00,0.00,0.60, 0.002),
							glm::vec4(0.00,0.40,0.60,0.7),
							glm::vec4(0.90,1.00,0.97, 0.5),
							glm::vec4(0.30,0.65,1.00, 0.1),
							glm::vec4(0.20,0.60,1.00, 0.001) ,
							glm::vec4(0.6,1,1.00, 0.007) };
		counter = rand() % 3;
		check = 0;
		eliceRotMul = 0.5f;
		accelerate = 0;
		decreaseFuel = 1;
		decreaseFuelBy = 0.1f;
		posBarX = 6.42;
		scaleBarX = 0.49f;
		gameOver = 0;
		collisionWithFuel = 0;
		collisionWithObstacle = 0;
		lifeCounter = 3;
		index = glm::vec4(-1);
	}
}

void Laborator5::FrameStart()
{
	glClearColor(1.00, 0.70, 0.4, 1);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glm::ivec2 resolution = window->GetResolution();
	// sets the screen area where to draw
	glViewport(0, 0, resolution.x, resolution.y);
}

void Laborator5::Update(float deltaTimeSeconds)
{
	{
		collisionWithFuel = 0;
		angleElice += deltaTimeSeconds * 80;
		check = 0;
		//fuel bar
		if (decreaseFuel) {
			float old_length = 7.6 - posBarX;
			posBarX += decreaseFuelBy * deltaTimeSeconds;
			float new_length = 7.6 - posBarX;
			scaleBarX += (new_length / old_length) * deltaTimeSeconds;
			if (posBarX > 8.15) {
				gameOver = 1;
				//exit(0);
			}
		} else {
			posBarX = posBarX;
			scaleBarX = scaleBarX;
		}
		//fuel bar front
		{
			glm::mat4 modelMatrix6 = glm::mat4(1);
			modelMatrix6 = glm::translate(modelMatrix6, glm::vec3(posBarX, 2.71, 0));
			modelMatrix6 = glm::scale(modelMatrix6, glm::vec3(scaleBarX, 0.28, 0.3));
			RenderSimpleMesh(camera1, meshes["fuelBar2"], shaders["VertexNormal"], modelMatrix6);
		}
		//fuel bar back
		{
			glm::mat4 modelMatrix6 = glm::mat4(1);
			modelMatrix6 = glm::translate(modelMatrix6, glm::vec3(6.4, 2.7, 0));
			modelMatrix6 = glm::scale(modelMatrix6, glm::vec3(0.5, 0.3, 0.3));
			RenderSimpleMesh(camera1, meshes["fuelBar1"], shaders["VertexNormal"], modelMatrix6);
		}
		//check if the game is over and animate the plane
		if (gameOver == 1) {
			yPlane -= sin(deltaTimeSeconds) * 3;
		}
		if (yPlane < -3) {
			cout << "Game Over!" << "\n";
			exit(0);
		}

		//plane
		{
			glm::mat4 modelMatrix = glm::mat4(1);
			modelMatrix = glm::translate(modelMatrix, glm::vec3(-2.5f, yPlane, 0));
			modelMatrix = glm::rotate(modelMatrix, angle * deltaTimeSeconds, glm::vec3(0, 0, -1));
			modelMatrix = glm::rotate(modelMatrix, 1.8f, glm::vec3(0, 1, 0));
			modelMatrix = glm::scale(modelMatrix, glm::vec3(0.08, 0.08, 0.08));
			RenderSimpleMesh(camera, meshes["plane"], shaders["ShaderTema"], modelMatrix);
		}
		//propeller
		{
			glm::mat4 modelMatrix1 = glm::mat4(1);
			modelMatrix1 = glm::translate(modelMatrix1, glm::vec3(-1.63f, yPlane + 0.16, -0.27f));
			modelMatrix1 = glm::rotate(modelMatrix1, angleElice * eliceRotMul, glm::vec3(1, 0, 0));
			modelMatrix1 = glm::rotate(modelMatrix1, 1.8f, glm::vec3(0, 1, 0));
			modelMatrix1 = glm::scale(modelMatrix1, glm::vec3(0.3, 0.04, 4));
			RenderSimpleMesh(camera, meshes["elice"], shaders["ShaderTema"], modelMatrix1);
		}
		//clouds
		//clouds rotation and movement
		if (up == 1) {
			cloudY += sin(deltaTimeSeconds) * 0.2f * glm::vec4(1);
			if (cloudY[0] >= 3.5f) {
				cloudY -= sin(deltaTimeSeconds) * 0.2f * glm::vec4(1);
				up = 0;
			}
		}
		else {
			cloudY -= sin(deltaTimeSeconds) * 0.2f * glm::vec4(1);
			if (cloudY[0] <= 2) {
				cloudY += sin(deltaTimeSeconds) * 0.2f * glm::vec4(1);
				up = 1;
			}
		}
		//cloud1
		{
			cloudX -= deltaTimeSeconds * 3 * glm::vec4(1);
			for (int i = 0; i < 4; i++) {
				if (cloudX[i] <= -9) {
					cloudX[i] = 9;
				}
				glm::mat4 modelMatrix2 = glm::mat4(1);
				//modelMatrix2 = glm::rotate(modelMatrix2, deltaTimeSeconds*angleCloudsRotation, glm::vec3(0, 0, -1));
				modelMatrix2 = glm::translate(modelMatrix2, glm::vec3(cloudX[i], cloudY[i], -2));
				modelMatrix2 = glm::rotate(modelMatrix2, angleElice * 0.005f, glm::vec3(1, 0, 0));
				modelMatrix2 = glm::rotate(modelMatrix2, angleCloud[i], axisCloud[i]);
				modelMatrix2 = glm::scale(modelMatrix2, scaleFactorCloud[i] * glm::vec3(1));
				RenderSimpleMesh(camera, meshes["cube"], shaders["VertexNormal"], modelMatrix2);
			}
		}
		//cloud2
		{
			cloudX1 -= deltaTimeSeconds * 3 * glm::vec4(1);
			for (int i = 0; i < 4; i++) {
				if (cloudX1[i] <= -10) {
					cloudX1[i] = 10;
				}
				glm::mat4 modelMatrix2 = glm::mat4(1);
				//modelMatrix2 = glm::rotate(modelMatrix2, deltaTimeSeconds * angleCloudsRotation,glm::vec3(0,0,-1));
				modelMatrix2 = glm::translate(modelMatrix2, glm::vec3(cloudX1[i], cloudY[i], 1));
				modelMatrix2 = glm::rotate(modelMatrix2, angleElice * 0.003f, glm::vec3(1, 0, 0));
				modelMatrix2 = glm::rotate(modelMatrix2, angleCloud[i], axisCloud[i]);
				modelMatrix2 = glm::scale(modelMatrix2, scaleFactorCloud[i] * glm::vec3(1) - glm::vec3(0.01, 0.01, 0.01));
				RenderSimpleMesh(camera, meshes["cube"], shaders["VertexNormal"], modelMatrix2);
			}
		}
		//cloud3
		{
			cloudX2 -= deltaTimeSeconds * 3 * glm::vec4(1);
			for (int i = 0; i < 4; i++) {
				if (cloudX2[i] <= -10) {
					cloudX2[i] = 10;
				}
				glm::mat4 modelMatrix2 = glm::mat4(1);
				//modelMatrix2 = glm::rotate(modelMatrix2, deltaTimeSeconds * angleCloudsRotation, glm::vec3(0, 0, -1));
				modelMatrix2 = glm::translate(modelMatrix2, glm::vec3(cloudX2[i], cloudY[i], -3));
				modelMatrix2 = glm::rotate(modelMatrix2, angleElice * 0.006f, glm::vec3(1, 0, 0));
				modelMatrix2 = glm::rotate(modelMatrix2, angleCloud[i], axisCloud[i]);
				modelMatrix2 = glm::scale(modelMatrix2, scaleFactorCloud[i] * (glm::vec3(1) + glm::vec3(0.01, 0.01, 0.01)));
				RenderSimpleMesh(camera, meshes["cube"], shaders["VertexNormal"], modelMatrix2);
			}
		}

		//fuel
		fuelTranslationY += deltaTimeSeconds * 1.2f*glm::vec4(1);
		fuelTranslationX -= deltaTimeSeconds * 2.5f*glm::vec4(1);
		for (int i = 0; i < 4; i++) {
			if (fuelTranslationX[i] <= -10) {
				fuelTranslationX[i] = 8;
				index[i] = -1;
			}
			collisionWithFuel = 0;
			float aux = sin(fuelTranslationY[i]) + 0.8f;
			//check collisions for fuel
			double distance = sqrt((-1.63f - (double)fuelTranslationX[i]) * (-1.63f - (double)fuelTranslationX[i]) +
				(yPlane - (double)aux) * (yPlane - (double)aux) +
				(double)((double)-0.27f - 0) * (-0.27 - 0));
			if (distance < 0.5f) {
				if (index[i] == -1) {
					collisionWithFuel = 1;
				}
				else {
					collisionWithFuel = 0;
				}
			}
			if (collisionWithFuel == 1) {
				//refill 
				index[i] = i;
				if (((double)posBarX - 0.1f) > 6.42) {
					posBarX -= 0.2f;
				}
			} else {
				if (index[i] == -1) {
					glm::mat4 modelMatrix3 = glm::mat4(1);
					modelMatrix3 = glm::translate(modelMatrix3, glm::vec3(fuelTranslationX[i], aux, 0));
					modelMatrix3 = glm::rotate(modelMatrix3, angleElice * 0.08f, glm::vec3(1, 0, 0));
					modelMatrix3 = glm::rotate(modelMatrix3, 1.15f, glm::vec3(0, 1, 0));
					modelMatrix3 = glm::scale(modelMatrix3, glm::vec3(0.1, 0.1, 0.1));
					RenderSimpleMesh(camera, meshes["fuel"], shaders["VertexNormal"], modelMatrix3);
				}
			}
		}
		collisionWithObstacle = 0;
		//obstacole
		//obst1
		translateObst1X -= deltaTimeSeconds * 4;
		if (translateObst1X <= -10) {
			translateObst1X = 10;
		}
		//check collisions for obstacle
		double distance = sqrt((-1.63f - (double)translateObst1X) * (-1.63f - (double)translateObst1X) +
			(yPlane - (double)translateObst1Y) * (yPlane - (double)translateObst1Y) +
			(double)((double)-0.27f - 0) * (-0.27 - 0));
		if (distance < 0.5f) {
			collisionWithObstacle = 1;
		}
		if (collisionWithObstacle == 1) {
			translateObst1X = -9;
			//remove a life
			if (lifeCounter >= 1) {
				lifeCounter--;
			}
			if (lifeCounter == 0){
				gameOver = 1;
			}
		}
		collisionWithObstacle = 0;

		glm::mat4 modelMatrix4 = glm::mat4(1);
		modelMatrix4 = glm::translate(modelMatrix4, glm::vec3(translateObst1X, translateObst1Y, 0));
		modelMatrix4 = glm::rotate(modelMatrix4, angleElice * 0.04f, glm::vec3(1, 0, 0));
		modelMatrix4 = glm::rotate(modelMatrix4, 0.8f, glm::vec3(2, 1, 0));
		modelMatrix4 = glm::scale(modelMatrix4, glm::vec3(0.55, 0.4, 0.55));
		RenderSimpleMesh(camera, meshes["obstacle"], shaders["VertexNormal"], modelMatrix4);
		//obst2
		translateObst2X -= deltaTimeSeconds * 4;
		if (translateObst2X <= -10) {
			translateObst2X = 10;
		}
		//check collisions for obstacle
		double distance1 = sqrt((-1.63f - (double)translateObst2X) * (-1.63f - (double)translateObst2X) +
			(yPlane - (double)translateObst2Y) * (yPlane - (double)translateObst2Y) +
			(double)((double)-0.27f - 0) * (-0.27 - 0));
		if (distance1 < 0.5f) {
			collisionWithObstacle = 1;
		}
		if (collisionWithObstacle == 1) {
			translateObst2X = -7;
			//remove a life
			if (lifeCounter >= 1) {
				lifeCounter--;
			}
			if (lifeCounter == 0) {
				gameOver = 1;
			}
		}
		collisionWithObstacle = 0;

		modelMatrix4 = glm::mat4(1);
		modelMatrix4 = glm::translate(modelMatrix4, glm::vec3(translateObst2X, translateObst2Y, 0));
		modelMatrix4 = glm::rotate(modelMatrix4, angleElice * 0.04f, glm::vec3(1, 0, 0));
		modelMatrix4 = glm::rotate(modelMatrix4, 0.8f, glm::vec3(2, 1, 0));
		modelMatrix4 = glm::scale(modelMatrix4, glm::vec3(0.55, 0.4, 0.55));
		RenderSimpleMesh(camera, meshes["obstacle"], shaders["VertexNormal"], modelMatrix4);
	}
	
	//sea
	{
		glm::mat4 modelMatrix5 = glm::mat4(1);
		modelMatrix5 = glm::translate(modelMatrix5, glm::vec3(-0.5, -9, 7));
		modelMatrix5 = glm::rotate(modelMatrix5, 1.5f, glm::vec3(1, 0, 0));
		modelMatrix5 = glm::scale(modelMatrix5, glm::vec3(2.5, 3, 1.5));
		modelMatrix5 = glm::rotate(modelMatrix5, angleElice * 0.01f, glm::vec3(0, 1, 0));
		RenderSimpleMesh(camera, meshes["sea"], shaders["ShaderTemaMare"], modelMatrix5);
	}

	check = 1;
	//vieti
	//viata1
	{
		if (lifeCounter >= 1) {
			glm::mat4 modelMatrix6 = glm::mat4(1);
			modelMatrix6 = glm::translate(modelMatrix6, glm::vec3(-4, 1.5, 0));
			modelMatrix6 = glm::scale(modelMatrix6, glm::vec3(0.3, 0.3, 0.3));
			RenderSimpleMesh(camera1, meshes["life"], shaders["ShaderTema"], modelMatrix6);
		}
	}
	//viata2 
	{
		if (lifeCounter >= 2) {
			glm::mat4 modelMatrix6 = glm::mat4(1);
			modelMatrix6 = glm::translate(modelMatrix6, glm::vec3(-3.3, 1.5, 0));
			modelMatrix6 = glm::scale(modelMatrix6, glm::vec3(0.3, 0.3, 0.3));
			RenderSimpleMesh(camera1, meshes["life"], shaders["ShaderTema"], modelMatrix6);
		}
	}
	//viata3
	{
		if (lifeCounter >= 3) {
			glm::mat4 modelMatrix6 = glm::mat4(1);
			modelMatrix6 = glm::translate(modelMatrix6, glm::vec3(-2.6, 1.5, 0));
			modelMatrix6 = glm::scale(modelMatrix6, glm::vec3(0.3, 0.3, 0.3));
			RenderSimpleMesh(camera1, meshes["life"], shaders["ShaderTema"], modelMatrix6);
		}
	}
}

void Laborator5::FrameEnd()
{
}

void Laborator5::RenderSimpleMesh(Laborator::Camera* camera, Mesh* mesh, Shader* shader, const glm::mat4& modelMatrix)
{
	if (!mesh || !shader || !shader->program)
		return;
	shader->Use();
	//uniforms needed in shaders
	{
		float t = Engine::GetElapsedTime();
		int locationCounter = glGetUniformLocation(shader->program, "counter");
		glUniform1i(locationCounter, counter);
		int locationCheck = glGetUniformLocation(shader->program, "check");
		glUniform1i(locationCheck, check);
		int locationBonus = glGetUniformLocation(shader->program, "time");
		glUniform1f(locationBonus, t);
		int locationAdd = glGetUniformLocation(shader->program, "add");
		glUniform1i(locationAdd, add);
		int locationColor1 = glGetUniformLocation(shader->program, "color1");
		glUniform4fv(locationColor1, 1, glm::value_ptr(colorsForTheSea[0]));
		int locationColor2 = glGetUniformLocation(shader->program, "color2");
		glUniform4fv(locationColor2, 1, glm::value_ptr(colorsForTheSea[1]));
		int locationColor3 = glGetUniformLocation(shader->program, "color3");
		glUniform4fv(locationColor3, 1, glm::value_ptr(colorsForTheSea[2]));
		int locationColor4 = glGetUniformLocation(shader->program, "color4");
		glUniform4fv(locationColor4, 1, glm::value_ptr(colorsForTheSea[3]));
		int locationColor5 = glGetUniformLocation(shader->program, "color5");
		glUniform4fv(locationColor5, 1, glm::value_ptr(colorsForTheSea[4]));
		int locationColor6 = glGetUniformLocation(shader->program, "color6");
		glUniform4fv(locationColor6, 1, glm::value_ptr(colorsForTheSea[5]));
	}
	// render an object using the specified shader and the specified position
	glUniformMatrix4fv(shader->loc_view_matrix, 1, GL_FALSE, glm::value_ptr(camera->GetViewMatrix()));
	glUniformMatrix4fv(shader->loc_projection_matrix, 1, GL_FALSE, glm::value_ptr(projectionMatrix));
	glUniformMatrix4fv(shader->loc_model_matrix, 1, GL_FALSE, glm::value_ptr(modelMatrix));

	mesh->Render();
}

void Laborator5::OnInputUpdate(float deltaTime, int mods)
{
	// move the camera only if MOUSE_RIGHT button is pressed
	if (window->MouseHold(GLFW_MOUSE_BUTTON_RIGHT))
	{
		float cameraSpeed = 2.0f;

		if (window->KeyHold(GLFW_KEY_W)) {
			// TODO : translate the camera forward
			camera->TranslateForward(cameraSpeed * deltaTime);
		}

		if (window->KeyHold(GLFW_KEY_A)) {
			// TODO : translate the camera to the left
			camera->TranslateRight(cameraSpeed * deltaTime);
		}

		if (window->KeyHold(GLFW_KEY_S)) {
			// TODO : translate the camera backwards
			camera->TranslateForward(-cameraSpeed * deltaTime);
		}

		if (window->KeyHold(GLFW_KEY_D)) {
			// TODO : translate the camera to the right
			camera->TranslateRight(-cameraSpeed * deltaTime);
		}

		if (window->KeyHold(GLFW_KEY_Q)) {
			// TODO : translate the camera down
			camera->TranslateUpword(-cameraSpeed * deltaTime);
		}

		if (window->KeyHold(GLFW_KEY_E)) {
			// TODO : translate the camera up
			camera->TranslateUpword(cameraSpeed * deltaTime);
		}
	}
	//acceleration of the plane
	if (window->KeyHold(GLFW_KEY_A)) {
		decreaseFuelBy = 0.2f;
		eliceRotMul = 1.0f;
	}
	else {
		decreaseFuelBy = 0.1f;
		eliceRotMul = 0.5f;
	}
}

void Laborator5::OnKeyPress(int key, int mods)
{
	if (key == GLFW_KEY_T)
	{
		renderCameraTarget = !renderCameraTarget;
	}
	//change the perspective
	if (key == GLFW_KEY_F) {
		changePerspective = changePerspective ^ 1;
		add ^= 1;
		if (changePerspective == 1) {
			camera->Set(glm::vec3(-5, 4, 0), glm::vec3(0, 1, 0), glm::vec3(1, 0, 0));
		}
		else {
			camera->Set(glm::vec3(0, 3, 5), glm::vec3(0, 1, 0), glm::vec3(0, 1, 0));
		}
	}
}

void Laborator5::OnKeyRelease(int key, int mods)
{
}

void Laborator5::OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY)
{
	// add mouse move event
	// the plane follows the mouse
	if (window->MouseHold(GLFW_MOUSE_BUTTON_LEFT)) {
		float sensivityOY = 0.01f;
		float sOX = 0.008f;
		yPlane -= deltaY * sensivityOY;
		angle += deltaY * sOX;
	}
	if (window->MouseHold(GLFW_MOUSE_BUTTON_RIGHT))
	{
		float sensivityOX = 0.001f;
		float sensivityOY = 0.001f;

		if (window->GetSpecialKeyState() == 0) {
			renderCameraTarget = false;
			camera->RotateFirstPerson_OX(-deltaY * sensivityOX);
			camera->RotateFirstPerson_OY(-deltaX * sensivityOY);
		}

		if (window->GetSpecialKeyState() && GLFW_MOD_CONTROL) {
			renderCameraTarget = true;
			camera->RotateThirdPerson_OX(-deltaY * sensivityOX);
			camera->RotateThirdPerson_OY(-deltaX * sensivityOY);
		}

	}
}

void Laborator5::OnMouseBtnPress(int mouseX, int mouseY, int button, int mods)
{
}

void Laborator5::OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods)
{
}

void Laborator5::OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY)
{
}

void Laborator5::OnWindowResize(int width, int height)
{
}
