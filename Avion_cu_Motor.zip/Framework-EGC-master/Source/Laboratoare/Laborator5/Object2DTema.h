#pragma once

#include <string>

#include <include/glm.h>
#include <Core/GPU/Mesh.h>

namespace Object2DTema
{
	Mesh* CreateFuelBar(std::string name, glm::vec3 leftBottomCorner, bool fill, glm::vec3 color);
	Mesh* CreateObstacle(std::string name, glm::vec3 leftBottomCorner, bool fill);
	Mesh* CreateFuel(std::string name, glm::vec3 leftBottomCorner, bool fill);
	Mesh * CreateCube(std::string name, glm::vec3 leftBottomCorner, bool fill);

}

