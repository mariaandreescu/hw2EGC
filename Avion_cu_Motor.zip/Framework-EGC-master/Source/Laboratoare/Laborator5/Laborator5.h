#pragma once
#include <Component/SimpleScene.h>
#include "LabCamera.h"
#include <Laboratoare\Laborator5\LabCamera.h>
#include <Engine\Component\Camera\Camera.h>
#include <Component\CameraInput.h>
#include <Component\CameraInput.h>
#include <Core\Engine.h>

class Laborator5 : public SimpleScene
{
	public:
		Laborator5();
		~Laborator5();
		
		void Init() override;

	private:
		void FrameStart() override;
		void Update(float deltaTimeSeconds) override;
		void FrameEnd() override;

		void RenderSimpleMesh(Laborator::Camera* camera, Mesh* mesh, Shader* shader, const glm::mat4& modelMatrix);
		void OnInputUpdate(float deltaTime, int mods) override;
		void OnKeyPress(int key, int mods) override;
		void OnKeyRelease(int key, int mods) override;
		void OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY) override;
		void OnMouseBtnPress(int mouseX, int mouseY, int button, int mods) override;
		void OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods) override;
		void OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY) override;
		void OnWindowResize(int width, int height) override;

	protected:
		Laborator::Camera *camera;
		Laborator::Camera* camera1;
		glm::mat4 projectionMatrix;
		bool renderCameraTarget;
		float fov;
		float length;
		int up;
		float yPlane;
		float angle;
		float angleElice;
		float translateXElice;
		float translateYElice;
		glm::vec4 cloudX;
		glm::vec4 cloudX1;
		glm::vec4 cloudX2;
		glm::vec4 cloudY;
		glm::vec4 cloudY1;
		glm::vec4 cloudY2;
		glm::vec4 angleCloud;
		std::vector<glm::vec3> axisCloud;
		glm::vec4 scaleFactorCloud;
		float angleCloudsRotation;
		glm::vec4 fuelTranslationX;
		glm::vec4 fuelTranslationY;
		glm::vec4 ostacleTranslationX;
		glm::vec4 obstacleTranslationY;
		float value;
		float value1;
		float translateObst1X;
		float translateObst2X;
		float translateObst1Y;
		float translateObst2Y;
		int changePerspective;
		int accelerate;
		int add;
		std::vector<glm::vec4> colorsForTheSea;
		int counter;
		int check;
		float eliceRotMul;
		int decreaseFuel;
		float decreaseFuelBy;
		float posBarX;
		float scaleBarX;
		int gameOver;
		int collisionWithFuel;
		int collisionWithObstacle;
		int lifeCounter;
		glm::vec4 index;
		glm::vec4 auxiliary;
};
