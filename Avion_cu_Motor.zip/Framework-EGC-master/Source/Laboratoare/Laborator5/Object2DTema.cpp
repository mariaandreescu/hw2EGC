#include <Core/Engine.h>
#include "..\Laborator5\Object2DTema.h"

Mesh* Object2DTema::CreateFuelBar(std::string name, glm::vec3 leftBottomCorner, bool fill, glm::vec3 color)
{
	glm::vec3 corner = leftBottomCorner;
	std::vector<VertexFormat> vertices =
	{
		/*0 - A*/VertexFormat(corner, glm::vec3(1),color),
		/*1 - B*/VertexFormat(corner + glm::vec3(4,0,0), glm::vec3(1),color),
		/*2 - C*/VertexFormat(corner + glm::vec3(4,1,0), glm::vec3(1),color),
		/*3 - D*/VertexFormat(corner + glm::vec3(0,1,0), glm::vec3(1),color),
	
	};
	std::vector<unsigned short> indices =
	{0,2,1,  0,2,3};

	Mesh* fuelBar = new Mesh(name);
	if (!fill) {
		fuelBar->SetDrawMode(GL_LINE_LOOP);
	}
	fuelBar->InitFromData(vertices, indices);
	return fuelBar;

}

Mesh* Object2DTema::CreateObstacle(std::string name, glm::vec3 leftBottomCorner, bool fill) {
	glm::vec4 color = glm::vec4(0.80, 0.00, 0.00, 1);
	glm::vec4 color1 = glm::vec4(0.50, 0.00, 0.00, 1);

	glm::vec3 corner = leftBottomCorner;
	std::vector<VertexFormat> vertices =
	{
		/*0 - E*/VertexFormat(corner, color1),
		/*1 - A*/VertexFormat(corner+glm::vec3(0,0.59,0), glm::vec3(1),color1),
		/*2 - B*/VertexFormat(corner+ glm::vec3(-0.32,0.53,0), glm::vec3(1),color),
		/*3 - C*/VertexFormat(corner+ glm::vec3(-0.61,0.19,0), glm::vec3(1),color),
		/*4 - D*/VertexFormat(corner+ glm::vec3(-0.57,-0.3,0), glm::vec3(1),color),
		/*5 - F*/VertexFormat(corner+ glm::vec3(-0.15,-0.61,0), glm::vec3(1),color),
		/*6 - G*/VertexFormat(corner+ glm::vec3(0.25,-0.57,0), glm::vec3(1),color),
		/*7 - H*/VertexFormat(corner+ glm::vec3(0.52,-0.22,0), glm::vec3(1),color),
		/*8 - I*/VertexFormat(corner+ glm::vec3(0.56,0.19,0), glm::vec3(1),color),
		/*9 - J*/VertexFormat(corner+ glm::vec3(0.32,0.48,0), glm::vec3(1),color),
		/*10 - K*/VertexFormat(corner+ glm::vec3(0,0,0.5), glm::vec3(1),color1),
		/*11 - L*/VertexFormat(corner+ glm::vec3(0,0,-0.5), glm::vec3(1),color1)
	};

	std::vector<unsigned short> indices =
	{
		0,1,2,   1,2,10,   11,2,1,
		0,2,3,   2,3,10,   11,3,2,
		0,3,4,   3,4,10,   11,4,3,
		0,4,5,   4,5,10,   11,5,4,
		0,5,6,   5,6,10,   11,6,5,
		0,6,7,   6,7,10,   11,7,6,
		0,7,8,   7,8,10,   11,8,7,
		0,8,9,   8,9,10,   11,9,8,
		0,9,1,   9,1,10,   11,9,1
		
	};
	Mesh* obstacle = new Mesh(name);
	if (!fill) {
		obstacle->SetDrawMode(GL_LINE_LOOP);
	}
	obstacle->InitFromData(vertices, indices);
	return obstacle;
}

Mesh* Object2DTema::CreateFuel(std::string name, glm::vec3 leftBottomCorner, bool fill) {
	glm::vec4 color = glm::vec4(0.30, 0.88, 1.00, 1.0);
	glm::vec4 color1 = glm::vec4(0.6, 1, 1, 1.0);

	glm::vec3 corner = leftBottomCorner;
	std::vector<VertexFormat> vertices =
	{
		/*0 - B*/VertexFormat(corner, glm::vec3(1),color),
		/*1 - A*/VertexFormat(corner + glm::vec3(0,-1,0), glm::vec3(1),color1),
		/*2 - C*/VertexFormat(corner + glm::vec3(-1,0,0),glm::vec3(1), color1),
		/*3 - E*/VertexFormat(corner + glm::vec3(0,1,0),glm::vec3(1), color1),
		/*4 - F*/VertexFormat(corner + glm::vec3(1,0,0), glm::vec3(1),color1),
		/*5 - D*/VertexFormat(corner + glm::vec3(0,0,1),glm::vec3(1), color),
		/*6 - G*/VertexFormat(corner + glm::vec3(0,0,-1),glm::vec3(1), color)
	};

	std::vector<unsigned short> indices =
	{
		0,3,2,
		0,4,3,
		0,1,4,
		0,2,1,
		2,5,1,
		1,5,4,
		3,4,5,
		3,5,2,
		2,6,1,
		1,6,4,
		3,4,6,
		3,6,2,
	};
	Mesh* fuel = new Mesh(name);
	if (!fill) {
		fuel->SetDrawMode(GL_LINE_LOOP);
	}
	fuel->InitFromData(vertices, indices);
	return fuel;
}

Mesh* Object2DTema::CreateCube(std::string name, glm::vec3 leftBottomCorner, bool fill)
{
	glm::vec4 color1 = glm::vec4(1.00, 0.85, 0.70, 0.5);
	glm::vec4 color2 = glm::vec4(1.00, 1.00, 0.80, 0.1);

	glm::vec3 corner = leftBottomCorner;
	std::vector<VertexFormat> vertices = 
	{
		VertexFormat(glm::vec3(-1, -1,  1), glm::vec3(0, 1, 1), color1),
		VertexFormat(glm::vec3(1, -1,  1), glm::vec3(1, 0, 1), color2),
		VertexFormat(glm::vec3(-1,  1,  1), glm::vec3(1, 0, 0), color1),
		VertexFormat(glm::vec3(1,  1,  1), glm::vec3(0, 1, 0), color1),
		VertexFormat(glm::vec3(-1, -1, -1), glm::vec3(1, 1, 1), color1),
		VertexFormat(glm::vec3(1, -1, -1), glm::vec3(0, 1, 1), color2),
		VertexFormat(glm::vec3(-1,  1, -1), glm::vec3(1, 1, 0), color1),
		VertexFormat(glm::vec3(1,  1, -1), glm::vec3(0, 0, 1), color1)
	};

	std::vector<unsigned short> indices =
	{
		0, 1, 2,		1, 3, 2,
		2, 3, 7,		2, 7, 6,
		1, 7, 3,		1, 5, 7,
		6, 7, 4,		7, 5, 4,
		0, 4, 1,		1, 4, 5,
		2, 6, 4,		0, 2, 4,
	};
	Mesh* cube = new Mesh(name);
	
	if (!fill) {
		cube->SetDrawMode(GL_LINE_LOOP);
	}
	cube->InitFromData(vertices, indices);
	return cube;
}

